CREATIVE DESIGN STUDIO — WEBSITE PACKAGE

Files:
- index.html: your responsive portfolio website
- assets/profile-photo.jpeg: your uploaded portrait
- assets/creative-design-studio-logo.png: logo created for your portfolio

Preview:
Open index.html in a web browser.

Before publishing:
1. Open index.html in a text editor.
2. Replace 'Add your email address' and 'Add your number' with your real contact details.
3. Replace the six portfolio placeholders with your own design images.
4. To add an image, copy it into the assets folder and edit the relevant placeholder in index.html to use:
   <img src="assets/your-image.jpg" alt="Project description">

Important:
This is a standalone website package. Google Sites does not import a complete HTML website as a finished site.
You can publish this package free using GitHub Pages, or recreate its sections inside Google Sites.
